package helloworld;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class RetrieveLocationResponse{
    List location = new ArrayList<>();


}
